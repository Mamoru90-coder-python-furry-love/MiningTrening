import pygame

class SoundSystem:
    def __init__(self):
        pygame.mixer.init()
        self.sounds = {}

    def load_sound(self, name, file_path):
        """
        Завантажує звук у систему.
        :param name: Назва звуку.
        :param file_path: Шлях до файлу звуку.
        """
        try:
            self.sounds[name] = pygame.mixer.Sound(file_path)
        except pygame.error as e:
            print(f"Помилка завантаження звуку {file_path}: {e}")

    def play_sound(self, name):
        """
        Відтворює звук за назвою.
        :param name: Назва звуку.
        """
        if name in self.sounds:
            self.sounds[name].play()

    def stop_sound(self, name):
        """
        Зупиняє відтворення звуку.
        :param name: Назва звуку.
        """
        if name in self.sounds:
            self.sounds[name].stop()

    def set_volume(self, name, volume):
        """
        Встановлює гучність звуку.
        :param name: Назва звуку.
        :param volume: Гучність (0.0 - 1.0).
        """
        if name in self.sounds:
            self.sounds[name].set_volume(volume)
