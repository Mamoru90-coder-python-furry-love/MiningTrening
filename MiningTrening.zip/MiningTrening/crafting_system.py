from typing import Dict, List

class Recipe:
    def __init__(self, name: str, ingredients: Dict[str, int], result: str, result_quantity: int):
        self.name = name
        self.ingredients = ingredients
        self.result = result
        self.result_quantity = result_quantity

class CraftingSystem:
    def __init__(self):
        self.recipes: List[Recipe] = [
            Recipe("Залізна кирка", {"Вугілля": 5, "Залізо": 10}, "Залізна кирка", 1),
            Recipe("Зілля енергії", {"Вугілля": 2, "Трава": 3}, "Зілля енергії", 1),
            Recipe("Шахтарська лампа", {"Золото": 5, "Скло": 2}, "Шахтарська лампа", 1)
        ]

    def craft(self, player_inventory, recipe_name: str) -> bool:
        recipe = next((r for r in self.recipes if r.name == recipe_name), None)
        if not recipe:
            return False

        # Check if player has all ingredients
        for ingredient, quantity in recipe.ingredients.items():
            if player_inventory.get(ingredient, 0) < quantity:
                return False

        # Deduct ingredients and add result
        for ingredient, quantity in recipe.ingredients.items():
            player_inventory[ingredient] -= quantity
        player_inventory[recipe.result] = player_inventory.get(recipe.result, 0) + recipe.result_quantity
        return True

    def display_recipes(self):
        """
        Виводить список доступних рецептів.
        """
        for recipe in self.recipes:
            ingredients = ", ".join([f"{k}: {v}" for k, v in recipe.ingredients.items()])
            print(f"{recipe.name}: {ingredients} -> {recipe.result} x{recipe.result_quantity}")
