class Quest:
    def __init__(self, name, description, condition, reward):
        """
        Ініціалізація квесту.
        :param name: Назва квесту.
        :param description: Опис квесту.
        :param condition: Умова виконання (функція).
        :param reward: Нагорода за виконання.
        """
        self.name = name
        self.description = description
        self.condition = condition
        self.reward = reward
        self.completed = False

    def check_completion(self, player):
        """
        Перевіряє, чи виконано квест.
        :param player: Об'єкт гравця.
        """
        if not self.completed and self.condition(player):
            self.completed = True
            return True
        return False


class QuestSystem:
    def __init__(self):
        """
        Ініціалізація системи квестів.
        """
        self.quests = []

    def add_quest(self, quest):
        """
        Додає новий квест.
        :param quest: Об'єкт Quest.
        """
        self.quests.append(quest)

    def check_quests(self, player):
        """
        Перевіряє всі квести для гравця.
        :param player: Об'єкт гравця.
        """
        completed_quests = []
        for quest in self.quests:
            if quest.check_completion(player):
                completed_quests.append(quest.name)
                player["gold"] += quest.reward
        return completed_quests

    def reset_quests(self):
        """
        Скидає всі виконані квести.
        """
        for quest in self.quests:
            quest.completed = False
