from typing import Dict, List, Callable
import pygame

class Item:
    def __init__(self, name: str, description: str, value: int, icon: str, category: str):
        self.name = name
        self.description = description
        self.value = value
        self.icon = self.load_icon(icon)
        self.category = category  # New: category for filtering

    def load_icon(self, icon_path: str) -> pygame.Surface:
        try:
            return pygame.image.load(f"assets/icons/{icon_path}")
        except:
            return pygame.Surface((32, 32))

class Inventory:
    def __init__(self):
        self.items: Dict[str, int] = {}
        self.capacity = 100  # Increased capacity
        self.equipped_items = {}
        self.sort_key: Callable[[str], any] = lambda item: item  # Default sort by name
        self.filter_category: str = None  # New: filter by category

    def add_item(self, item_name: str, quantity: int = 1) -> bool:
        if len(self.items) >= self.capacity:
            return False
        self.items[item_name] = self.items.get(item_name, 0) + quantity
        return True

    def remove_item(self, item_name: str, quantity: int = 1) -> bool:
        if item_name in self.items and self.items[item_name] >= quantity:
            self.items[item_name] -= quantity
            if self.items[item_name] == 0:
                del self.items[item_name]
            return True
        return False

    def sort_items(self, key: Callable[[str], any]):
        self.sort_key = key

    def filter_items(self, category: str):
        self.filter_category = category

    def get_sorted_filtered_items(self) -> List[str]:
        items = list(self.items.keys())
        if self.filter_category:
            items = [item for item in items if self.get_item_category(item) == self.filter_category]
        return sorted(items, key=self.sort_key)

    def get_item_category(self, item_name: str) -> str:
        # Example logic for determining category
        if "кирка" in item_name.lower():
            return "tools"
        elif "зілля" in item_name.lower():
            return "consumables"
        return "misc"

    def display_capacity(self):
        """
        Виводить поточну місткість інвентаря.
        """
        print(f"Використано: {len(self.items)}/{self.capacity}")
