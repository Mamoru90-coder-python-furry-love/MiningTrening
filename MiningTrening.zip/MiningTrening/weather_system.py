import random
import pygame

class WeatherSystem:
    def __init__(self):
        """
        Ініціалізація системи погоди.
        """
        self.weather_types = ["Сонячно", "Дощ", "Сніг", "Туман"]
        self.current_weather = random.choice(self.weather_types)

    def change_weather(self):
        """
        Змінює поточну погоду.
        """
        self.current_weather = random.choice(self.weather_types)

    def display_weather(self):
        """
        Виводить поточну погоду.
        """
        print(f"Поточна погода: {self.current_weather}")

    def apply_weather_effects(self, player):
        """
        Застосовує ефекти погоди до гравця.
        :param player: Об'єкт гравця.
        """
        if self.current_weather == "Дощ":
            player["energy"] -= 5  # Зменшує енергію через слизькі умови
        elif self.current_weather == "Сніг":
            player["mining_speed"] = max(1, player.get("mining_speed", 1) - 1)  # Зменшує швидкість копання
        elif self.current_weather == "Сонячно":
            player["energy"] += 5  # Збільшує енергію через гарну погоду

    def draw_weather_effects(self, screen):
        """
        Малює візуальні ефекти погоди на екрані.
        :param screen: Екран для малювання.
        """
        if self.current_weather == "Дощ":
            for _ in range(50):  # Малює краплі дощу
                x = random.randint(0, screen.get_width())
                y = random.randint(0, screen.get_height())
                pygame.draw.line(screen, (0, 0, 255), (x, y), (x, y + 5), 1)
        elif self.current_weather == "Сніг":
            for _ in range(50):  # Малює сніжинки
                x = random.randint(0, screen.get_width())
                y = random.randint(0, screen.get_height())
                pygame.draw.circle(screen, (255, 255, 255), (x, y), 2)
