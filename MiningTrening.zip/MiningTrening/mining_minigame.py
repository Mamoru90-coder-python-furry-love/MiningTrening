import pygame
import random

class MiningMinigame:
    def __init__(self, screen):
        """
        Ініціалізація міні-гри.
        :param screen: Екран для малювання.
        """
        self.screen = screen
        self.target = random.randint(50, 100)
        self.progress = 0

    def play(self):
        """
        Запускає міні-гру.
        """
        font = pygame.font.Font(None, 36)
        clock = pygame.time.Clock()

        while self.progress < self.target:
            self.screen.fill((0, 0, 0))
            pygame.draw.rect(self.screen, (255, 255, 255), (100, 300, 600, 50), 2)
            pygame.draw.rect(self.screen, (0, 255, 0), (100, 300, int(600 * (self.progress / self.target)), 50))

            text = font.render(f"Прогрес: {self.progress}/{self.target}", True, (255, 255, 255))
            self.screen.blit(text, (300, 200))

            pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return False
                if event.type == pygame.KEYDOWN and event.key == pygame.K_SPACE:
                    self.progress += random.randint(1, 5)

            clock.tick(30)

        return True

    def reset(self):
        """
        Скидає прогрес міні-гри.
        """
        self.target = random.randint(50, 100)
        self.progress = 0
