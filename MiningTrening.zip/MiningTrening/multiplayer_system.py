class MultiplayerSystem:
    def __init__(self):
        """
        Ініціалізація системи мультиплеєра.
        """
        self.players = []

    def add_player(self, player_name):
        """
        Додає нового гравця.
        :param player_name: Ім'я гравця.
        """
        self.players.append({"name": player_name, "gold": 0, "energy": 100})

    def display_players(self):
        """
        Виводить список гравців.
        """
        for player in self.players:
            print(f"Гравець: {player['name']}, Золото: {player['gold']}, Енергія: {player['energy']}")

    def trade_gold(self, from_player, to_player, amount):
        """
        Дозволяє гравцям обмінюватися золотом.
        :param from_player: Гравець, який передає золото.
        :param to_player: Гравець, який отримує золото.
        :param amount: Кількість золота.
        """
        sender = next((p for p in self.players if p["name"] == from_player), None)
        receiver = next((p for p in self.players if p["name"] == to_player), None)

        if sender and receiver and sender["gold"] >= amount:
            sender["gold"] -= amount
            receiver["gold"] += amount
            return True
        return False
