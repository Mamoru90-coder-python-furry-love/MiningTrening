import pygame
import random

class Particle:
    def __init__(self, x, y, color, lifetime):
        """
        Ініціалізація частинки.
        :param x: Початкова координата X.
        :param y: Початкова координата Y.
        :param color: Колір частинки.
        :param lifetime: Тривалість життя частинки.
        """
        self.x = x
        self.y = y
        self.color = color
        self.lifetime = lifetime
        self.size = random.randint(2, 5)
        self.velocity = [random.uniform(-1, 1), random.uniform(-1, 1)]

    def update(self):
        """
        Оновлює стан частинки.
        """
        self.x += self.velocity[0]
        self.y += self.velocity[1]
        self.lifetime -= 1


class ParticleSystem:
    def __init__(self):
        """
        Ініціалізація системи частинок.
        """
        self.particles = []

    def create_particles(self, x, y, color, count):
        """
        Створює нові частинки.
        :param x: Координата X.
        :param y: Координата Y.
        :param color: Колір частинок.
        :param count: Кількість частинок.
        """
        for _ in range(count):
            self.particles.append(Particle(x, y, color, random.randint(20, 50)))

    def update_and_draw(self, screen):
        """
        Оновлює та малює частинки.
        :param screen: Екран для малювання.
        """
        for particle in self.particles[:]:
            particle.update()
            if particle.lifetime <= 0:
                self.particles.remove(particle)
            else:
                pygame.draw.circle(screen, particle.color, (int(particle.x), int(particle.y)), particle.size)

    def clear_particles(self):
        """
        Очищає всі частинки.
        """
        self.particles.clear()
