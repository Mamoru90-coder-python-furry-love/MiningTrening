import os
import requests  # Import requests for downloading images
import pygame
import random
import json
import time
from crafting_system import CraftingSystem
from sound_system import SoundSystem
from skill_tree_system import SkillTree, Skill
from multiplayer_system import MultiplayerSystem
from weather_system import WeatherSystem  # Fixed import
from enum import Enum  # Add this import for GameState

# Ініціалізація Pygame
pygame.init()

# Настройки вікна
WIDTH, HEIGHT = 800, 600
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Симулятор шахтаря")

# Кольори
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GRAY = (200, 200, 200)

# Шрифти
font = pygame.font.Font(None, 36)
big_font = pygame.font.Font(None, 48)

# Файл для збереження даних
SAVE_FILE = "miner_game_save.json"
USER_FILE = "miner_game_users.json"

# Directory for assets
ASSETS_DIR = "D:\\Coding\\MiningTrening\\assets\\backgrounds"
BACKGROUND_IMAGE_URL = "https://example.com/mining_background.jpg"  # Replace with a valid URL

def download_image(url, save_path):
    """
    Завантажує зображення за URL, якщо воно не існує.
    :param url: URL зображення.
    :param save_path: Шлях для збереження зображення.
    """
    if not os.path.exists(save_path):
        print(f"Завантаження зображення: {url}")
        try:
            response = requests.get(url, stream=True)
            response.raise_for_status()
            with open(save_path, "wb") as file:
                for chunk in response.iter_content(1024):
                    file.write(chunk)
            print(f"Зображення збережено: {save_path}")
        except requests.RequestException as e:
            print(f"Помилка завантаження зображення: {e}")
    else:
        print(f"Зображення вже існує: {save_path}")

# Ensure the assets directory exists
os.makedirs(ASSETS_DIR, exist_ok=True)

# Download the background image if missing
background_image_path = os.path.join(ASSETS_DIR, "mining_background.jpg")
download_image(BACKGROUND_IMAGE_URL, background_image_path)

# Load background image
background_image = pygame.image.load(background_image_path)

# Функція для збереження даних
def save_game(player_data):
    with open(SAVE_FILE, "w") as file:
        json.dump(player_data, file)

# Функція для завантаження даних
def load_game():
    try:
        with open(SAVE_FILE, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return {"name": "Гравець", "energy": 100, "gold": 0}

# Функція для збереження користувачів
def save_users(users):
    with open(USER_FILE, "w") as file:
        json.dump(users, file)

# Функція для завантаження користувачів
def load_users():
    try:
        with open(USER_FILE, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        return {}

# Updated draw_text function to support centered text
def draw_text(text, font, color, x, y, center=False):
    surface = font.render(text, True, color)
    if center:
        rect = surface.get_rect(center=(x, y))
        screen.blit(surface, rect)
    else:
        screen.blit(surface, (x, y))

# Система реєстрації та авторизації
def register_or_login():
    users = load_users()
    while True:
        screen.fill(WHITE)
        draw_text("1. Реєстрація", big_font, BLACK, 200, 200)
        draw_text("2. Авторизація", big_font, BLACK, 200, 300)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:  # Реєстрація
                    return register(users)
                elif event.key == pygame.K_2:  # Авторизація
                    return login(users)

def register(users):
    screen.fill(WHITE)
    draw_text("Введіть ім'я користувача:", big_font, BLACK, 200, 200)
    pygame.display.flip()
    username = input("Ім'я користувача: ")
    if username in users:
        print("Користувач вже існує!")
        return register(users)
    users[username] = {"password": input("Пароль: "), "data": {"name": username, "energy": 100, "gold": 0}}
    save_users(users)
    return users[username]["data"]

def login(users):
    screen.fill(WHITE)
    draw_text("Введіть ім'я користувача:", big_font, BLACK, 200, 200)
    pygame.display.flip()
    username = input("Ім'я користувача: ")
    if username not in users:
        print("Користувач не знайдений!")
        return login(users)
    password = input("Пароль: ")
    if users[username]["password"] != password:
        print("Невірний пароль!")
        return login(users)
    return users[username]["data"]

# Функція для виконання тренування з вибором рівня складності
def do_exercise(player):
    difficulties = {
        "Легкий": {"reps": random.randint(5, 10), "time_per_rep": 3, "reward": 30},
        "Середній": {"reps": random.randint(10, 15), "time_per_rep": 2, "reward": 50},
        "Складний": {"reps": random.randint(15, 20), "time_per_rep": 1, "reward": 70},
    }

    # Вибір рівня складності
    selected_difficulty = None
    while not selected_difficulty:
        screen.fill(WHITE)
        draw_text("Виберіть рівень складності:", big_font, BLACK, 200, 150)
        draw_text("1. Легкий", font, GREEN, 200, 200)
        draw_text("2. Середній", font, GREEN, 200, 250)
        draw_text("3. Складний", font, GREEN, 200, 300)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    selected_difficulty = "Легкий"
                elif event.key == pygame.K_2:
                    selected_difficulty = "Середній"
                elif event.key == pygame.K_3:
                    selected_difficulty = "Складний"

    exercise = random.choice(["Присідання", "Віджимання", "Стрибки"])
    reps = difficulties[selected_difficulty]["reps"]
    time_limit = reps * difficulties[selected_difficulty]["time_per_rep"]
    reward = difficulties[selected_difficulty]["reward"]

    # Таймер зворотного відліку
    for countdown in range(3, 0, -1):
        screen.fill(WHITE)
        draw_text(f"Початок через: {countdown}", big_font, RED, 300, 250)
        pygame.display.flip()
        time.sleep(1)

    start_time = time.time()
    while True:
        elapsed_time = time.time() - start_time
        remaining_time = max(0, time_limit - elapsed_time)

        screen.fill(WHITE)
        draw_text(f"Вправа: {exercise}", big_font, BLACK, 200, 150)
        draw_text(f"Зробіть {reps} повторень", font, BLACK, 200, 200)
        draw_text(f"Залишилось часу: {int(remaining_time)} секунд", font, BLACK, 200, 250)
        draw_text("Натисніть [Пробіл], щоб завершити", font, GREEN, 200, 300)
        draw_text("Натисніть [T], щоб додати 10 секунд", font, GREEN, 200, 350)
        pygame.display.flip()

        if remaining_time <= 0:
            draw_text("Час вийшов!", font, RED, 200, 400)
            pygame.display.flip()
            time.sleep(2)
            return

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    player["energy"] += reward
                    return
                elif event.key == pygame.K_t:
                    time_limit += 10

# Define GameState as an Enum
class GameState(Enum):
    MENU = 1
    INVENTORY = 2
    CRAFTING = 3

# Fix indentation and undefined variables in the Button class
class Button:
    def __init__(self, x, y, width, height, text, color, hover_color):
        """
        Ініціалізація кнопки.
        :param x: Координата X.
        :param y: Координата Y.
        :param width: Ширина кнопки.
        :param height: Висота кнопки.
        :param text: Текст кнопки.
        :param color: Колір кнопки.
        :param hover_color: Колір кнопки при наведенні.
        """
        self.rect = pygame.Rect(x, y, width, height)
        self.text = text
        self.color = color
        self.hover_color = hover_color
        self.current_color = color

    def draw(self, screen, font):
        """
        Малює кнопку на екрані.
        :param screen: Екран для малювання.
        :param font: Шрифт для тексту.
        """
        pygame.draw.rect(screen, self.current_color, self.rect, border_radius=10)
        text_surface = font.render(self.text, True, BLACK)
        text_rect = text_surface.get_rect(center=self.rect.center)
        screen.blit(text_surface, text_rect)

    def is_hovered(self, mouse_pos):
        """
        Перевіряє, чи наведена миша на кнопку.
        :param mouse_pos: Позиція миші.
        """
        return self.rect.collidepoint(mouse_pos)

    def update(self, mouse_pos):
        """
        Оновлює колір кнопки залежно від наведення миші.
        :param mouse_pos: Позиція миші.
        """
        self.current_color = self.hover_color if self.is_hovered(mouse_pos) else self.color

class Game:
    def __init__(self):
        self.crafting_system = CraftingSystem()
        self.sound_system = SoundSystem()
        self.skill_tree = SkillTree()
        self.buttons[GameState.MENU].append(
            Button(300, 620, 200, 50, "Крафтинг", GREEN, (0, 200, 0))
        )
        self.buttons[GameState.INVENTORY].append(
            Button(20, 480, 200, 50, "Сортувати за назвою", GREEN, (0, 200, 0))
        )
        self.buttons[GameState.INVENTORY].append(
            Button(20, 540, 200, 50, "Фільтрувати інструменти", GREEN, (0, 200, 0))
        )

        # Завантаження звуків
        self.sound_system.load_sound("gold_mine", "assets/sounds/gold_mine.wav")
        self.sound_system.load_sound("level_up", "assets/sounds/level_up.wav")

        # Додавання навичок
        self.skill_tree.add_skill(Skill("Швидке копання", "Збільшує швидкість копання", 50, self.increase_mining_speed))
        self.skill_tree.add_skill(Skill("Енергозбереження", "Зменшує витрати енергії", 30, self.reduce_energy_cost))

    def increase_mining_speed(self, player):
        player["mining_speed"] = player.get("mining_speed", 1) + 1

    def reduce_energy_cost(self, player):
        player["energy_cost"] = player.get("energy_cost", 10) - 2

    def handle_button_click(self, button):
        if button.text == "Крафтинг":
            self.state = GameState.CRAFTING
        elif button.text == "Сортувати за назвою":
            self.inventory.sort_items(lambda item: item)
        elif button.text == "Фільтрувати інструменти":
            self.inventory.filter_items("tools")
        elif button.text == "Навички":
            self.display_skill_tree()

    def display_skill_tree(self):
        """
        Відображає дерево навичок у консолі.
        """
        self.skill_tree.display_skills()
        skill_name = input("Введіть назву навички для розблокування: ")
        skill = next((s for s in self.skill_tree.skills if s.name == skill_name), None)
        if skill and skill.unlock(self.player):
            print(f"Навичка '{skill_name}' розблокована!")
            self.sound_system.play_sound("level_up")
        else:
            print("Недостатньо очок досвіду або навичка вже розблокована.")

def pause_menu():
    """
    Відображає меню паузи.
    """
    while True:
        screen.fill(WHITE)
        draw_text("Пауза", big_font, BLACK, 300, 200)
        draw_text("1. Продовжити", font, GREEN, 300, 300)
        draw_text("2. Вийти в головне меню", font, GREEN, 300, 350)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_1:
                    return
                elif event.key == pygame.K_2:
                    main_menu()

# Add a new interface design for the main menu
def main_menu():
    """
    Відображає головне меню з новим дизайном.
    """
    buttons = [
        Button(300, 250, 200, 50, "Почати гру", GREEN, (0, 200, 0)),
        Button(300, 320, 200, 50, "Налаштування", BLUE, (0, 0, 200)),
        Button(300, 390, 200, 50, "Вийти", RED, (200, 0, 0)),
    ]

    while True:
        screen.blit(background_image, (0, 0))
        draw_text("Головне меню", big_font, WHITE, WIDTH // 2, 100, center=True)

        mouse_pos = pygame.mouse.get_pos()
        for button in buttons:
            button.update(mouse_pos)
            button.draw(screen, font)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if buttons[0].is_hovered(mouse_pos):  # Почати гру
                    return
                elif buttons[1].is_hovered(mouse_pos):  # Налаштування
                    settings_menu()
                elif buttons[2].is_hovered(mouse_pos):  # Вийти
                    pygame.quit()
                    exit()

# Add a settings menu
def settings_menu():
    """
    Відображає меню налаштувань.
    """
    buttons = [
        Button(300, 250, 200, 50, "Гучність", GREEN, (0, 200, 0)),
        Button(300, 320, 200, 50, "Графіка", BLUE, (0, 0, 200)),
        Button(300, 390, 200, 50, "Назад", RED, (200, 0, 0)),
    ]

    while True:
        screen.fill(GRAY)
        draw_text("Налаштування", big_font, BLACK, WIDTH // 2, 100, center=True)

        mouse_pos = pygame.mouse.get_pos()
        for button in buttons:
            button.update(mouse_pos)
            button.draw(screen, font)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if buttons[0].is_hovered(mouse_pos):  # Гучність
                    adjust_volume()
                elif buttons[1].is_hovered(mouse_pos):  # Графіка
                    adjust_graphics()
                elif buttons[2].is_hovered(mouse_pos):  # Назад
                    return

# Add volume adjustment functionality
def adjust_volume():
    """
    Відображає меню налаштування гучності.
    """
    volume = 50  # Default volume
    while True:
        screen.fill(GRAY)
        draw_text("Налаштування гучності", big_font, BLACK, WIDTH // 2, 100, center=True)
        draw_text(f"Гучність: {volume}%", font, BLACK, WIDTH // 2, 200, center=True)
        draw_text("Натисніть [←] або [→] для зміни", font, BLACK, WIDTH // 2, 300, center=True)
        draw_text("Натисніть [Esc] для виходу", font, BLACK, WIDTH // 2, 400, center=True)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    volume = max(0, volume - 10)
                elif event.key == pygame.K_RIGHT:
                    volume = min(100, volume + 10)
                elif event.key == pygame.K_ESCAPE:
                    return

# Add graphics adjustment functionality
def adjust_graphics():
    """
    Відображає меню налаштування графіки.
    """
    graphics_quality = "Середня"  # Default graphics quality
    qualities = ["Низька", "Середня", "Висока"]
    current_index = qualities.index(graphics_quality)

    while True:
        screen.fill(GRAY)
        draw_text("Налаштування графіки", big_font, BLACK, WIDTH // 2, 100, center=True)
        draw_text(f"Якість графіки: {graphics_quality}", font, BLACK, WIDTH // 2, 200, center=True)
        draw_text("Натисніть [←] або [→] для зміни", font, BLACK, WIDTH // 2, 300, center=True)
        draw_text("Натисніть [Esc] для виходу", font, BLACK, WIDTH // 2, 400, center=True)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT:
                    current_index = max(0, current_index - 1)
                    graphics_quality = qualities[current_index]
                elif event.key == pygame.K_RIGHT:
                    current_index = min(len(qualities) - 1, current_index + 1)
                    graphics_quality = qualities[current_index]
                elif event.key == pygame.K_ESCAPE:
                    return

def display_leaderboard(multiplayer_system):
    """
    Відображає таблицю лідерів гравців за кількістю золота.
    :param multiplayer_system: Система мультиплеєра.
    """
    screen.fill(WHITE)
    draw_text("Таблиця лідерів", big_font, BLACK, 300, 50)
    sorted_players = sorted(multiplayer_system.players, key=lambda p: p["gold"], reverse=True)
    y_offset = 150
    for idx, player in enumerate(sorted_players):
        draw_text(f"{idx + 1}. {player['name']} - {player['gold']} золота", font, BLACK, 200, y_offset)
        y_offset += 50
    pygame.display.flip()
    time.sleep(5)  # Показує таблицю лідерів протягом 5 секунд

# Updated main game loop with background and cleaner layout
def main():
    player = register_or_login()
    clock = pygame.time.Clock()
    weather_system = WeatherSystem()  # Ініціалізація системи погоди
    multiplayer_system = MultiplayerSystem()  # Ініціалізація мультиплеєра
    multiplayer_system.add_player(player["name"])  # Додаємо поточного гравця

    buttons = [
        Button(20, 200, 300, 50, "Копати золото", GREEN, (0, 200, 0)),
        Button(20, 260, 300, 50, "Виконати тренування", GREEN, (0, 200, 0)),
        Button(20, 320, 300, 50, "Змінити погоду", GREEN, (0, 200, 0)),
        Button(20, 380, 300, 50, "Зберегти гру", GREEN, (0, 200, 0)),
        Button(20, 440, 300, 50, "Таблиця лідерів", GREEN, (0, 200, 0)),
        Button(20, 500, 300, 50, "Вийти", RED, (200, 0, 0)),
    ]

    running = True
    while running:
        screen.blit(background_image, (0, 0))

        # Відображення даних гравця
        draw_text(f"Ім'я: {player['name']}", font, WHITE, 20, 20)
        draw_text(f"Енергія: {player['energy']}", font, WHITE, 20, 60)
        draw_text(f"Золото: {player['gold']}", font, WHITE, 20, 100)
        draw_text(f"Погода: {weather_system.current_weather}", font, BLUE, 20, 140)

        # Малювання кнопок
        mouse_pos = pygame.mouse.get_pos()
        for button in buttons:
            button.update(mouse_pos)
            button.draw(screen, font)

        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                save_game(player)
                running = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if buttons[0].is_hovered(mouse_pos):  # Копати золото
                    if player["energy"] > 0:
                        gold_found = random.randint(1, 10)
                        player["gold"] += gold_found
                        player["energy"] -= 10
                        draw_text(f"Ви знайшли {gold_found} золота!", font, WHITE, WIDTH // 2, HEIGHT // 2, center=True)
                        pygame.display.flip()
                        time.sleep(2)
                    else:
                        draw_text("У вас закінчилась енергія!", font, RED, WIDTH // 2, HEIGHT // 2, center=True)
                        pygame.display.flip()
                        time.sleep(2)
                elif buttons[1].is_hovered(mouse_pos):  # Виконати тренування
                    do_exercise(player)
                elif buttons[2].is_hovered(mouse_pos):  # Змінити погоду
                    weather_system.change_weather()
                    weather_system.apply_weather_effects(player)
                elif buttons[3].is_hovered(mouse_pos):  # Зберегти гру
                    save_game(player)
                    draw_text("Гру збережено!", font, GREEN, WIDTH // 2, HEIGHT // 2, center=True)
                    pygame.display.flip()
                    time.sleep(2)
                elif buttons[4].is_hovered(mouse_pos):  # Таблиця лідерів
                    display_leaderboard(multiplayer_system)
                elif buttons[5].is_hovered(mouse_pos):  # Вийти
                    save_game(player)
                    running = False

        clock.tick(30)

    pygame.quit()

if __name__ == "__main__":
    main_menu()
    main()