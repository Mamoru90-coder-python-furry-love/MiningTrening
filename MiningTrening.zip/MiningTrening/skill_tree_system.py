class Skill:
    def __init__(self, name, description, cost, effect):
        """
        Ініціалізація навички.
        :param name: Назва навички.
        :param description: Опис.
        :param cost: Вартість у очках досвіду.
        :param effect: Функція, яка застосовує ефект навички.
        """
        self.name = name
        self.description = description
        self.cost = cost
        self.effect = effect
        self.unlocked = False

    def unlock(self, player):
        """
        Розблоковує навичку, якщо у гравця достатньо очок досвіду.
        :param player: Об'єкт гравця.
        """
        if player["xp"] >= self.cost and not self.unlocked:
            player["xp"] -= self.cost
            self.effect(player)
            self.unlocked = True
            return True
        return False


class SkillTree:
    def __init__(self):
        """
        Ініціалізація дерева навичок.
        """
        self.skills = []

    def add_skill(self, skill):
        """
        Додає нову навичку до дерева.
        :param skill: Об'єкт Skill.
        """
        self.skills.append(skill)

    def display_skills(self):
        """
        Виводить список доступних навичок.
        """
        for skill in self.skills:
            status = "Розблоковано" if skill.unlocked else "Недоступно"
            print(f"{skill.name}: {skill.description} (Вартість: {skill.cost}) - {status}")

    def reset_skills(self, player):
        """
        Скидає всі навички та повертає очки досвіду гравцю.
        :param player: Об'єкт гравця.
        """
        for skill in self.skills:
            if skill.unlocked:
                player["xp"] += skill.cost
                skill.unlocked = False
