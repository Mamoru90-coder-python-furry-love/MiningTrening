import random

class MiningSystem:
    def __init__(self):
        """
        Ініціалізація системи копання.
        """
        self.resources = {
            "Вугілля": (1, 5),
            "Залізо": (2, 8),
            "Золото": (3, 10),
            "Діаманти": (5, 15)
        }

    def mine(self, player):
        """
        Копає ресурс для гравця.
        :param player: Об'єкт гравця.
        """
        if player["energy"] <= 0:
            return None

        resource, (min_amount, max_amount) = random.choice(list(self.resources.items()))
        amount = random.randint(min_amount, max_amount)
        player["energy"] -= 10
        return resource, amount

    def display_resources(self):
        """
        Виводить список доступних ресурсів.
        """
        for resource, (min_amount, max_amount) in self.resources.items():
            print(f"{resource}: {min_amount}-{max_amount}")
