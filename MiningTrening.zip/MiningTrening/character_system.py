class Character:
    def __init__(self, name, health, level):
        """
        Ініціалізація персонажа.
        :param name: Ім'я персонажа.
        :param health: Здоров'я персонажа.
        :param level: Рівень персонажа.
        """
        self.name = name
        self.health = health
        self.level = level

    def take_damage(self, amount):
        """
        Зменшує здоров'я персонажа.
        :param amount: Кількість шкоди.
        """
        self.health -= amount
        if self.health < 0:
            self.health = 0

    def heal(self, amount):
        """
        Відновлює здоров'я персонажа.
        :param amount: Кількість відновленого здоров'я.
        """
        self.health += amount
