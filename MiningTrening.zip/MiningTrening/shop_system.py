class ShopItem:
    def __init__(self, name, description, price):
        """
        Ініціалізація товару в магазині.
        :param name: Назва товару.
        :param description: Опис товару.
        :param price: Ціна товару.
        """
        self.name = name
        self.description = description
        self.price = price


class ShopSystem:
    def __init__(self):
        """
        Ініціалізація системи магазину.
        """
        self.items = []

    def add_item(self, item):
        """
        Додає товар до магазину.
        :param item: Об'єкт ShopItem.
        """
        self.items.append(item)

    def display_items(self):
        """
        Виводить список товарів у магазині.
        """
        for item in self.items:
            print(f"{item.name}: {item.description} (Ціна: {item.price})")

    def buy_item(self, player, item_name):
        """
        Дозволяє гравцю купити товар.
        :param player: Об'єкт гравця.
        :param item_name: Назва товару.
        """
        item = next((i for i in self.items if i.name == item_name), None)
        if item and player["gold"] >= item.price:
            player["gold"] -= item.price
            return item.name
        return None

    def sell_item(self, player, item_name, price):
        """
        Дозволяє гравцю продати товар.
        :param player: Об'єкт гравця.
        :param item_name: Назва товару.
        :param price: Ціна продажу.
        """
        if item_name in player["inventory"]:
            player["inventory"].remove(item_name)
            player["gold"] += price
            return True
        return False
