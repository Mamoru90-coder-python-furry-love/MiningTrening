class Achievement:
    def __init__(self, name, description, condition):
        """
        Ініціалізація досягнення.
        :param name: Назва досягнення.
        :param description: Опис досягнення.
        :param condition: Умова для отримання досягнення (функція).
        """
        self.name = name
        self.description = description
        self.condition = condition
        self.unlocked = False

    def check_condition(self, player):
        """
        Перевіряє, чи виконана умова для досягнення.
        :param player: Об'єкт гравця.
        """
        if not self.unlocked and self.condition(player):
            self.unlocked = True
            return True
        return False


class AchievementSystem:
    def __init__(self):
        """
        Ініціалізація системи досягнень.
        """
        self.achievements = []

    def add_achievement(self, achievement):
        """
        Додає нове досягнення до системи.
        :param achievement: Об'єкт Achievement.
        """
        self.achievements.append(achievement)

    def check_achievements(self, player):
        """
        Перевіряє всі досягнення для гравця.
        :param player: Об'єкт гравця.
        """
        unlocked = []
        for achievement in self.achievements:
            if achievement.check_condition(player):
                unlocked.append(achievement.name)
        return unlocked

    def reset_achievements(self):
        """
        Скидає всі досягнення.
        """
        for achievement in self.achievements:
            achievement.unlocked = False
